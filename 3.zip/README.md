# Mulch Webview Magisk KSU

Este proyecto ha sido creado con el fin de facilitar la instalcion de Mulch WebView como predeterminado en su dispositivo Android.
