#Cambios

 + NEW: Instalador totalmente online
 + NEW: ahora puede actualizar directamente desde Magisk/KernelSU
 + Si quiere obtener la version mas reciente de Mulch WebView solo flashee mi modulo de nuevo

