# Mulch Webview Magisk KSU

Este proyecto ha sido creado con el fin de facilitar la instalación de la mas reciente version de Mulch WebView como predeterminado en su dispositivo Android.
